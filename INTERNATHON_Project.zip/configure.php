<?php 
$conn = mysqli_connect("localhost","root","","internathon") or die("Connection failed: ".mysqli_connect_error());
$hostname='https://localhost/INTERNATHON_Project/';
?>

